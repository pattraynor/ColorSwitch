# ColorSwitch

A simple game implemented with SpriteKit framework and Swift 4.2

![](https://www.dropbox.com/s/5idom4z0g5fpulo/color_switch.gif?raw=1)
